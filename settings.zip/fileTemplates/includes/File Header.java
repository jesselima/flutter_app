/**
 * Created by ${USER} on ${DATE}.
 * This is a part of the project ${PROJECT_NAME}.
 */
